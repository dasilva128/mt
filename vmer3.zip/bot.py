# bot.py - Production-ready Video Merge Bot (entrypoint)
import asyncio
import logging
import signal
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, Message, CallbackQuery
from configs import Config
from utils.logger import setup_logging
from helpers.queue import QueueManager
from helpers.merger import Merger
from helpers.thumbs import Thumbnailer
from database import Database

setup_logging()

logger = logging.getLogger(__name__)

db = Database(Config.DB_PATH)
queue = QueueManager(db)
merger = Merger(Config, queue)
thumb = Thumbnailer(Config)

app = Client(
    name=Config.SESSION_NAME,
    api_id=Config.API_ID,
    api_hash=Config.API_HASH,
    bot_token=Config.BOT_TOKEN,
    workers=8
)

@app.on_message(filters.private & filters.command('start'))
async def start_handler(client: Client, m: Message):
    await db.add_user(m.from_user.id)
    await m.reply_text(
        Config.START_TEXT,
        disable_web_page_preview=True,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("Developer", url=Config.DEVELOPER_URL)],
            [InlineKeyboardButton("Open Settings", callback_data="open_settings")]
        ])
    )

@app.on_message(filters.private & (filters.video | filters.document) & ~filters.edited)
async def handle_video(client: Client, m: Message):
    # Validate file extension
    media = m.video or m.document
    if not media or not getattr(media, 'file_name', None):
        return await m.reply_text("File name not found.")
    ext = media.file_name.rsplit('.', 1)[-1].lower()
    if ext not in Config.ALLOWED_FORMATS:
        return await m.reply_text(f"Format not allowed. Allowed: {', '.join(Config.ALLOWED_FORMATS)}")

    # Add to persistent queue
    await db.touch_user_dir(m.from_user.id)
    await queue.enqueue(m.from_user.id, m.message_id)
    await m.reply_text(f"Added to queue. Use /merge to start merging or send more files (max {Config.MAX_VIDEOS}).")

@app.on_message(filters.private & filters.command('merge'))
async def cmd_merge(client: Client, m: Message):
    user_id = m.from_user.id
    queued = await queue.get_queue(user_id)
    if not queued or len(queued) < 2:
        return await m.reply_text("Need at least two videos to merge.")
    status_msg = await m.reply_text("Starting merge...")

    try:
        merged_path = await merger.merge_user_videos(user_id, queued, status_msg)
    except Exception as e:
        logger.exception("Merge failed")
        await status_msg.edit("Merge failed. Check logs.")
        await queue.clear(user_id)
        return

    # generate thumbnail
    thumb_path = await thumb.generate(merged_path, user_id)
    # send result
    await status_msg.edit("Uploading merged file...")
    await client.send_document(
        chat_id=user_id,
        document=merged_path,
        thumb=thumb_path,
        caption=f"✅ Merged by @{(await client.get_me()).username}"
    )
    await status_msg.delete()
    await queue.clear(user_id)

@app.on_callback_query()
async def callbacks(client: Client, cb: CallbackQuery):
    if cb.data == "open_settings":
        await cb.answer("Settings not implemented in this scaffold.", show_alert=True)

def _shutdown():
    logger.info("Shutting down gracefully...")
    merger.shutdown_all()
    try:
        app.stop()
    except Exception:
        pass

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, _shutdown)
    app.run()

# configs.py - environment driven config
import os

class Config:
    SESSION_NAME = os.getenv('SESSION_NAME', 'videomerge_bot')
    API_ID = int(os.getenv('API_ID', '0'))
    API_HASH = os.getenv('API_HASH', '')
    BOT_TOKEN = os.getenv('BOT_TOKEN', '')
    DB_PATH = os.getenv('DB_PATH', 'data/users.db')
    DOWN_PATH = os.getenv('DOWN_PATH', 'downloads')
    ALLOWED_FORMATS = ['mp4', 'mkv', 'webm', 'mov', 'avi']
    MAX_VIDEOS = int(os.getenv('MAX_VIDEOS', '10'))
    DEFAULT_FORMAT = os.getenv('DEFAULT_FORMAT', 'mp4')
    START_TEXT = os.getenv('START_TEXT', 'Send me videos to merge. Use /merge to start.')
    DEVELOPER_URL = os.getenv('DEVELOPER_URL', 'https://t.me/savior_128')

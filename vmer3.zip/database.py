# database.py - simple async-friendly SQLite wrapper and schema
import sqlite3
import asyncio
import os
import logging

logger = logging.getLogger(__name__)

class Database:
    def __init__(self, path='users.db'):
        self.path = path
        self._init_db()

    def _init_db(self):
        os.makedirs(os.path.dirname(self.path) or '.', exist_ok=True)
        con = sqlite3.connect(self.path, isolation_level=None)
        cur = con.cursor()
        cur.execute("""CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY,
            joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS queue(
            user_id INTEGER,
            message_id INTEGER
        )""")
        con.commit()
        con.close()

    async def add_user(self, uid: int):
        await asyncio.get_running_loop().run_in_executor(None, self._add_user_sync, uid)

    def _add_user_sync(self, uid):
        con = sqlite3.connect(self.path)
        con.execute("INSERT OR IGNORE INTO users(id) VALUES(?)", (uid,))
        con.commit()
        con.close()

    async def execute(self, query: str, params=()):
        await asyncio.get_running_loop().run_in_executor(None, self._execute_sync, query, params)

    def _execute_sync(self, query, params):
        con = sqlite3.connect(self.path)
        con.execute(query, params)
        con.commit()
        con.close()

    async def fetch_all(self, query: str, params=()):
        return await asyncio.get_running_loop().run_in_executor(None, self._fetch_all_sync, query, params)

    def _fetch_all_sync(self, query, params):
        con = sqlite3.connect(self.path)
        cur = con.cursor()
        cur.execute(query, params)
        rows = cur.fetchall()
        con.close()
        return rows

    async def touch_user_dir(self, user_id: int):
        path = os.path.join(os.getcwd(), 'downloads', str(user_id))
        await asyncio.get_running_loop().run_in_executor(None, lambda: os.makedirs(path, exist_ok=True))

# Industrial Video Merge Bot - Production Scaffold

## Features
- Persistent SQLite-backed queue
- Safe ffmpeg concat handling (escaped paths)
- Per-user asyncio Lock to avoid race conditions
- Thumbnail generation with ffmpeg + Pillow fallback
- Structured logging

## Run (local)
1. Set env vars: API_ID, API_HASH, BOT_TOKEN
2. `pip install -r requirements.txt`
3. `python bot.py`

## Docker & production
Add a small systemd service or Dockerfile example included.

## Notes
This scaffold is production-oriented but still requires integration testing, secrets management, and optional Redis for scale.

# helpers/safe_cmd.py
import shlex
from pathlib import Path

def safe_path_for_ffmpeg(path: str) -> str:
    # ffmpeg concat expects: file 'path' -- but must escape single quotes
    p = Path(path).as_posix()
    p_escaped = p.replace("'", "'\\''")
    return f"'{p_escaped}'"

# helpers/thumbs.py - uses ffmpeg to reliably extract thumbnail, fallback to Pillow
import os
import asyncio
import random
import logging
from PIL import Image

logger = logging.getLogger(__name__)

class Thumbnailer:
    def __init__(self, config):
        self.config = config
        os.makedirs(self.config.DOWN_PATH, exist_ok=True)

    async def generate(self, video_path: str, user_id: int):
        out = os.path.join(self.config.DOWN_PATH, str(user_id), "thumb.jpg")
        # choose a random second between 1 and 3 if duration unknown
        cmd = [
            'ffmpeg', '-y', '-hide_banner',
            '-ss', '3',
            '-i', video_path,
            '-frames:v', '1',
            out
        ]
        proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        await proc.communicate()
        if os.path.exists(out):
            try:
                img = Image.open(out).convert('RGB')
                img.thumbnail((320, 320))
                img.save(out, 'JPEG')
                return out
            except Exception:
                logger.exception('Thumbnail generation failed, removing and returning None')
                try:
                    os.remove(out)
                except:
                    pass
        return None

# helpers/merger.py
import asyncio
import os
import shlex
import tempfile
import pathlib
import logging
from typing import List
from .safe_cmd import safe_path_for_ffmpeg

logger = logging.getLogger(__name__)

class MergeError(Exception):
    pass

class Merger:
    def __init__(self, config, queue_manager):
        self.config = config
        self.queue = queue_manager
        # track running processes by user_id -> subprocess
        self._running = {}
        self._locks = {}

    def _ensure_lock(self, user_id):
        if user_id not in self._locks:
            self._locks[user_id] = asyncio.Lock()
        return self._locks[user_id]

    async def merge_user_videos(self, user_id: int, message_ids: List[int], status_message):
        lock = self._ensure_lock(user_id)
        async with lock:
            user_dir = os.path.join(self.config.DOWN_PATH, str(user_id))
            os.makedirs(user_dir, exist_ok=True)
            listfile = os.path.join(user_dir, 'input.txt')
            paths = []
            # download messages (QueueManager guarantees message IDs are valid)
            for mid in message_ids:
                path = await self.queue.download_message_to(user_id, mid, user_dir)
                if not path or not os.path.exists(path):
                    logger.warning("Missing downloaded file for %s - %s", user_id, mid)
                    continue
                paths.append(path)

            if len(paths) < 2:
                raise MergeError("Not enough valid videos to merge")

            # write safe concat list
            with open(listfile, 'w', encoding='utf-8') as f:
                for p in paths:
                    f.write(f"file {safe_path_for_ffmpeg(p)}\n")

            out_name = f"merged_{int(asyncio.get_event_loop().time())}.{self.config.DEFAULT_FORMAT}"
            out_path = os.path.join(user_dir, out_name)

            cmd = [
                'ffmpeg',
                '-hide_banner', '-y',
                '-f', 'concat', '-safe', '0',
                '-protocol_whitelist', 'file,pipe,crypto,https,tcp,udp',
                '-i', listfile,
                '-c', 'copy',
                out_path
            ]

            logger.info("Running ffmpeg for user %s: %s", user_id, ' '.join(shlex.quote(x) for x in cmd))
            proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            self._running[user_id] = proc
            try:
                # stream stderr to status_message (if provided) and to logs
                while True:
                    line = await proc.stderr.readline()
                    if not line:
                        break
                    logger.debug("ffmpeg %s: %s", user_id, line.decode(errors='ignore').strip())
                    try:
                        await status_message.edit(f"Merging...\n{line.decode(errors='ignore').strip()}")
                    except Exception:
                        pass
                rc = await proc.wait()
                if rc != 0:
                    raise MergeError(f"ffmpeg exited with {rc}")
            finally:
                self._running.pop(user_id, None)

            if not os.path.exists(out_path):
                raise MergeError("Output file not created")

            return out_path

    def cancel_user(self, user_id: int):
        proc = self._running.get(user_id)
        if proc and proc.returncode is None:
            proc.kill()
            logger.info("Killed ffmpeg for user %s", user_id)

    def shutdown_all(self):
        for uid, p in list(self._running.items()):
            try:
                p.kill()
            except Exception:
                pass

# helpers/queue.py - persistent queue using SQLite and helper for downloading messages
import os
import sqlite3
import asyncio
import logging
from typing import List

logger = logging.getLogger(__name__)

class QueueManager:
    def __init__(self, database):
        self.db = database
        # in-memory locks per user to avoid race conditions
        self.locks = {}

    async def _lock(self, user_id):
        if user_id not in self.locks:
            self.locks[user_id] = asyncio.Lock()
        return self.locks[user_id]

    async def enqueue(self, user_id: int, message_id: int):
        async with await self._lock(user_id):
            await self.db.execute("INSERT INTO queue(user_id, message_id) VALUES(?, ?)", (user_id, message_id))

    async def get_queue(self, user_id: int) -> List[int]:
        rows = await self.db.fetch_all("SELECT message_id FROM queue WHERE user_id=? ORDER BY rowid", (user_id,))
        return [r[0] for r in rows]

    async def clear(self, user_id: int):
        await self.db.execute("DELETE FROM queue WHERE user_id=?", (user_id,))

    async def download_message_to(self, user_id: int, message_id: int, dest_dir: str) -> str:
        # This function expects an external download mechanism; for safety we use Telethon/Pyrogram in bot to download.
        # Here we return a best-guess path used by bot.py via pyrogram's download_media (the bot will call download and store same path).
        # This scaffold assumes bot.download_media writes into dest_dir/<message_id>/<original_name>
        # So we search dest_dir for files in subdir named message_id
        sub = os.path.join(dest_dir, str(message_id))
        if not os.path.exists(sub):
            return ''
        # find first media file in sub
        for root, dirs, files in os.walk(sub):
            for f in files:
                if f.lower().endswith(('.mp4', '.mkv', '.webm', '.mov', '.avi')):
                    return os.path.join(root, f)
        return ''
